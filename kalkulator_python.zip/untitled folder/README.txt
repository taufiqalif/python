===Note===
File ini dibuat oleh
channel : Dede Rahmatz
semua orang boleh menggunakanya
tapi sebelumnya jangan lupa like
share dan susbcribe videonya
supaya membantu cahnnel ini
berkembang dan memberikan manfaat
untuk kalian semua

===Terimakasih==